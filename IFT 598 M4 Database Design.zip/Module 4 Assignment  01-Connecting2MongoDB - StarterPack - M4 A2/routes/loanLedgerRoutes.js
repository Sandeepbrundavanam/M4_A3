const express = require('express');
const customerController = require('../controllers/loanLedgerController');
const router = express.Router();

router
  .route('/')
  .get(loanLedgerController.getLoanLedger)
  .post(loanLedgerController.createLoanLedger);

router
  .route('/:id')
  .get(loanLedgerController.getLoanLedger)
  .patch(loanLedgerController.updateLoanLedger)
  .delete(loanLedgerController.deleteLoanLedger);

module.exports = router;
